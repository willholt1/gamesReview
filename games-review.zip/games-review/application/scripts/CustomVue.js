var app = new Vue({
    // Add the id here.
    el: '#',
    data: {
		// Create your data here.
    },    
    methods: {
    //    Add your methods here.       
    }
});