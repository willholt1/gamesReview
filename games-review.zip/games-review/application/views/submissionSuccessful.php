<?php
//redirect to previous page
redirect($_SERVER['HTTP_REFERER']);